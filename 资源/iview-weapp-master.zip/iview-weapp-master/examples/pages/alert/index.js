Page({
    handleClick() {
        console.log('alert-close');
    }
});
